# -*- encoding: utf-8 -*-
# This file is distributed under the same license as the Django package.
#

DATE_FORMAT = 'j F, Y'
TIME_FORMAT = 'g:i:s A'
# DATETIME_FORMAT = 
YEAR_MONTH_FORMAT = 'F Y'
MONTH_DAY_FORMAT = 'j F'
SHORT_DATE_FORMAT = 'j M, Y'
# SHORT_DATETIME_FORMAT = 
# FIRST_DAY_OF_WEEK = 
# DATE_INPUT_FORMATS = 
# TIME_INPUT_FORMATS = 
# DATETIME_INPUT_FORMATS = 
DECIMAL_SEPARATOR = '.'
THOUSAND_SEPARATOR = ','
# NUMBER_GROUPING = 
